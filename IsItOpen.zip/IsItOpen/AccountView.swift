//
//  AccountView.swift
//  IsItOpen
//
//  Created by Jimmy Keating on 3/19/24.
//

import SwiftUI

struct AccountView: View {
    var body: some View {
        Text("Account Authentication and Settings")
            .navigationTitle("Account")
    }
}
